# Daily AI News Email Automation

An n8n workflow that collects the top posts from Reddit's `r/artificial` community and emails a short daily digest.

## Workflow overview

1. **Every Morning 8AM** — runs daily at 8:00 AM.
2. **Get Reddit AI Posts** — sends a request to the Apify Reddit Scraper Lite actor for up to five posts from the daily top posts page of `r/artificial`.
3. **Send AI News Email** — sends an HTML email containing the post titles and links through Gmail.

**Timezone:** `Asia/Dubai`  
**Schedule:** Daily at 8:00 AM  
**Current exported state:** Inactive. Activate only after completing the setup and testing.

## Repository structure

```text
n8n-daily-ai-news-automation/
├── workflows/
│   └── daily-ai-news-email.json
├── README.md
└── .gitignore
```

## Requirements

- An n8n account (n8n Cloud or self-hosted)
- An Apify account and API credential
- A Gmail account connected to n8n using Gmail OAuth2

## Import and configure

1. Download `workflows/daily-ai-news-email.json` from this repository.
2. In n8n, create or open a workflow and use **Import from File** (or the equivalent workflow import option in your n8n version).
3. Open **Get Reddit AI Posts** and configure its HTTP authentication using your own Apify credential. The exported workflow intentionally does not include credentials.
4. Open **Send AI News Email**, connect your own Gmail OAuth2 credential, and replace `YOUR_EMAIL@example.com` with the recipient address you want to use.
5. Confirm the workflow timezone is `Asia/Dubai` and the schedule is set to 8:00 AM.
6. Run a manual test and verify that the email arrives with working Reddit post links.
7. Activate the workflow when everything is working.

## Security

- Never commit API tokens, OAuth tokens, passwords, or credential exports.
- Keep credentials in n8n's credential manager.
- The public-safe workflow file removes account-specific credential references and replaces the recipient address with a placeholder.
- Do not publish screenshots that expose account URLs, email addresses, tokens, or other private information.

## Customization

- Change the Reddit community URL in **Get Reddit AI Posts** to monitor another community.
- Adjust `maxItems` and `maxPostCount` in the request body to change the number of posts collected.
- Edit the subject and HTML message in **Send AI News Email** to customize the digest.

## Notes

This repository contains the exported workflow configuration. It does not contain Apify or Gmail credentials, and it cannot run independently of an n8n instance and those connected services.
